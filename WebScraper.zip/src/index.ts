import tata from 'tata-js'

$(document).ready(() => {
    let ScrapeButton = $("#scrape")
    let Input = $("#input")

    ScrapeButton.click(() => {
        tata.error('Hello World', 'CSSScript.Com')
    })
})